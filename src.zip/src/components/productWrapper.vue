
<template>
  <section
    :style="`width: ${width}px; height: ${height}px`"
    class="product-wrapper"
  >
    <img src="@/assets/image/home/defaultImage.png" alt="product" />
    <section class="describe">
      <section>
        <p>{{ type }}</p>
        <p :style="minText ? 'font-size: 14px': ''">{{ name }}</p>
        <p>${{ money }}</p>
      </section>
      <img src="@/assets/image/home/rightArrow.png" alt="rightArrow" />
    </section>
  </section>
</template>

<script lang="ts">
import { defineComponent } from "vue";
export default defineComponent({
  props: {
    width: {
      type: Number,
      default: 0,
    },
    height: {
      type: Number,
      default: 0,
    },
    type: {
      type: String,
      default: "",
    },
    name: {
      type: String,
      default: "",
    },
    minText: {
      type: Boolean,
      default: false,
    },
    money: {
      type: String,
      default: "",
    },
  },
});
</script>

<style lang="scss" scoped>
@import "@/style/global.scss";
.product-wrapper {
  border: 1px solid #e0e0e0;
  border-radius: 5px;
  overflow: hidden;
  img {
    display: block;
    width: 100%;
    height: calc(100% - 100px);
  }
  .describe {
    height: 100px - 40px;
    padding: 20px;
    border-top: 1px solid #e0e0e0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    section {
      p:first-child {
        color: rgba(117, 117, 117, 1);
        font-size: 14px;
      }
      p:nth-child(2) {
        color: rgba(0, 0, 0, 1);
        font-size: 16px;
      }
      p:last-child {
        color: $primary-color;
        font-size: 19px;
      }
    }
    img {
      width: 15px;
      height: 23px;
      cursor: pointer;
    }
  }
}
</style>