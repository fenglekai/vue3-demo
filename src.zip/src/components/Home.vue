<template>
  <div>
    <header class="home-header">
      <div class="home-logo">
        <img src="@/assets/image/home/Logo.png" alt="logo" />
      </div>
      <div class="search-login">
        <!-- <div>search</div> -->
        <button class="primary-btn">Log in</button>
        <button style="margin: 0 22px" class="primary-btn" plain>
          Sign up
        </button>
      </div>
    </header>
    <nav class="home-nav">
      <ul>
        <li>Home Decor</li>
        <li>Furniture</li>
        <li>Lighting</li>
        <li>Home Accents</li>
        <li>Rugs</li>
        <li>Outdoors</li>
        <li>Holidays</li>
        <li>Gifts</li>
        <li>Events</li>
      </ul>
    </nav>
    <article class="home-article">
      <!-- 顶部图片 start -->
      <section class="default-image">
        <img src="@/assets/image/home/defaultImage.png" alt="defaultImage" />
        <div class="carousel">carousel</div>
      </section>
      <!-- 顶部图片 end -->
      <!-- 内容区域 start -->
      <section class="content-wrapper">

        <article class="top-seller">
          <p class="seller-title">Top Seller</p>
          <section class="product-items">
            <section class="product-wrapper" v-for="item in 3" :key="item">
              <img src="@/assets/image/home/defaultImage.png" alt="product" />
              <section class="describe">
                <section>
                  <p>Cyrusshare</p>
                  <p>SAVA DECK300 Mountain Bike 29"</p>
                  <p>$1,399.99</p>
                </section>
                <img
                  src="@/assets/image/home/rightArrow.png"
                  alt="rightArrow"
                />
              </section>
            </section>
          </section>
          <div class="more-wrapper">
            <a class="to-more" href="#" @click.prevent>Explore More ></a>
          </div>
        </article>

        <article class="problem">
          <section>
            <p>Why Become Buyer?</p>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam feliultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
            <button class="into-btn">Apply to Buy</button>
          </section>
          <aside><img src="@/assets/image/home/defaultImage.png" alt="problem"></aside>
        </article>

        <article class="problem">
          <aside><img src="@/assets/image/home/defaultImage.png" alt="problem"></aside>
          <section>
            <p>Why Become Buyer?</p>
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam feliultricies nec, pellentesque eu, pretium quis, sem. Nulla consequat massa quis enim.</p>
            <button class="into-btn">Apply to Buy</button>
          </section>
        </article>

        <article class="product-wrapper">
          <section>
            
          </section>
          <section></section>
        </article>
      </section>
      <!-- 内容区域 end -->
      {{ message }}
    </article>
    <footer></footer>
  </div>
</template>

<script lang="ts">
import { reactive, toRefs } from "vue";
export default {
  setup() {
    const state = reactive({
      message: "home",
    });
    return {
      ...toRefs(state),
    };
  },
};
</script>

<style lang="scss" scoped>
@import "@/style/global.scss";
.home-header {
  width: 100vw;
  height: 100px;
  display: flex;
  justify-content: space-between;
  align-content: center;
  .home-logo {
    margin: 0 80px;
    line-height: 100px;
    font-size: 0;
    img {
      vertical-align: middle;
    }
  }
  .search-login {
    line-height: 100px;
  }
}
.home-nav {
  width: calc(100vw - 160px);
  height: 45px;
  background-color: rgba(244, 244, 244, 1);
  padding: 0 80px;
  ul {
    margin: 0;
    padding: 0;
    list-style: none;
    line-height: 45px;
    li {
      display: inline-block;
      margin-right: 25px;
      cursor: pointer;
    }
  }
}
.home-article {
  .default-image {
    position: relative;
    padding-bottom: 200px;
    img {
      width: 100%;
      height: auto;
      max-height: 100%;
    }
    .carousel {
      width: calc(100% - 160px);
      height: 300px;
      background-color: #ffffff;
      position: absolute;
      bottom: -150px;
      left: 5%;
      transform: translateY(-50%);
      box-shadow: 0 0 68px rgb(9, 9, 9, 0.3);
    }
  }
  .content-wrapper {
    width: calc(100% - 160px);
    margin: 85px auto 0 auto;
    .top-seller {
      .seller-title {
        font-size: 30px;
        color: $primary-color;
      }
      .product-items {
        display: flex;
        justify-content: space-between;
        .product-wrapper {
          width: 380px;
          height: 380px;
          border: 1px solid #e0e0e0;
          img {
            display: block;
            width: 100%;
            height: 280px;
          }
          .describe {
            height: 100px - 40px;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            section {
              p:first-child {
                color: rgba(117, 117, 117, 1);
                font-size: 14px;
              }
              p:nth-child(2) {
                color: rgba(0, 0, 0, 1);
                font-size: 16px;
              }
              p:last-child {
                color: $primary-color;
                font-size: 19px;
              }
            }
            img {
              width: 15px;
              height: 23px;
              cursor: pointer;
            }
          }
        }
      }
      .more-wrapper {
        margin-top: 37px;
        text-align: center;
        .to-more {
          font-size: 16px;
          color: rgba(117, 117, 117, 1);
          text-decoration: none;
        }
      }
    }
    .problem {
      width: 100%;
      display: flex;
      align-items: center;
      margin-top: 130px;
      section {
        flex: 1;
        p:first-child {
          font-size: 30px;
          color: $primary-color;
          margin-bottom: 20px;
        }
        button:last-child {
          margin-top: 16px;
        }
      }
      aside {
        flex: 1;
        text-align: center;
        img {
          width: 379px;
          height: 241px;
        }
      }
    }
    .product-wrapper {
      display: flex;
      justify-content: space-between;
      section {
        flex: 0.9;
        display: inherit;
      }
    }
  }
}
</style>