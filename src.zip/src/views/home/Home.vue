<template>
  <div>
    <header class="home-header">
      <div class="home-logo">
        <img src="@/assets/image/home/Logo.png" alt="logo" />
      </div>
      <div class="search-login">
        <!-- <div>search</div> -->
        <button class="primary-btn">Log in</button>
        <button style="margin: 0 22px" class="primary-btn" plain>
          Sign up
        </button>
      </div>
    </header>
    <nav class="home-nav">
      <ul>
        <li>Home Decor</li>
        <li>Furniture</li>
        <li>Lighting</li>
        <li>Home Accents</li>
        <li>Rugs</li>
        <li>Outdoors</li>
        <li>Holidays</li>
        <li>Gifts</li>
        <li>Events</li>
      </ul>
    </nav>
    <article class="home-article">
      <!-- 顶部图片 start -->
      <section class="default-image">
        <p class="content-text">We have dream to connect wholesalers to independent Customers
          <br><button class="into-btn">Explore</button>
        </p>
        <img src="@/assets/image/home/defaultImage.png" alt="defaultImage" />
        <div class="carousel">
          <img style="width: 12px; height: 20px;" src="@/assets/image/home/leftArrow.png" alt="leftArrow" />
          <img style="width: 12px; height: 20px;" src="@/assets/image/home/rightArrow.png" alt="rightArrow" />
        </div>
      </section>
      <!-- 顶部图片 end -->
      <!-- 内容区域 start -->
      <section class="content-wrapper">
        <!--  -->
        <article class="top-seller">
          <p class="seller-title">Top Seller</p>
          <section class="product-items">
            <productWrapperVue
              v-for="item in 3"
              :key="item"
              :width="380"
              :height="380"
              type="Cyrusshare"
              name="SAVA DECK300 Mountain Bike 29"
              money="1,399.99"
            />
          </section>
          <div class="more-wrapper">
            <a class="to-more" href="#" @click.prevent>Explore More ></a>
          </div>
        </article>

        <article class="problem">
          <section>
            <p>Why Become Buyer?</p>
            <p>
              Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean
              commodo ligula eget dolor. Aenean massa. Cum sociis natoque
              penatibus et magnis dis parturient montes, nascetur ridiculus mus.
              Donec quam feliultricies nec, pellentesque eu, pretium quis, sem.
              Nulla consequat massa quis enim.
            </p>
            <button class="into-btn">Apply to Buy</button>
          </section>
          <aside>
            <img src="@/assets/image/home/defaultImage.png" alt="problem" />
          </aside>
        </article>

        <article class="problem">
          <aside>
            <img src="@/assets/image/home/defaultImage.png" alt="problem" />
          </aside>
          <section>
            <p>Why Become Buyer?</p>
            <p>
              Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean
              commodo ligula eget dolor. Aenean massa. Cum sociis natoque
              penatibus et magnis dis parturient montes, nascetur ridiculus mus.
              Donec quam feliultricies nec, pellentesque eu, pretium quis, sem.
              Nulla consequat massa quis enim.
            </p>
            <button class="into-btn">Apply to Buy</button>
          </section>
        </article>

        <article class="more-product-wrapper">
          <section class="list-wrapper">
            <productWrapperVue
              style="margin-bottom: 70px"
              :width="606"
              :height="542"
              type="Cyrusshare"
              name="SAVA DECK300 Mountain Bike 29"
              :minText="true"
              money="1,399.99"
            />
            <div class="min-product-wrapper" v-for="item in 6" :key="item">
              <productWrapperVue
                :width="269"
                :height="294"
                type="Cyrusshare"
                name="SAVA DECK300 Mountain Bike 29"
                :minText="true"
                money="1,399.99"
              />
            </div>
          </section>
          <section class="list-wrapper">
            <div class="min-product-wrapper" v-for="item in 4" :key="item">
              <productWrapperVue
                :width="269"
                :height="294"
                type="Cyrusshare"
                name="SAVA DECK300 Mountain Bike 29"
                :minText="true"
                money="1,399.99"
              />
            </div>
            <productWrapperVue
              style="margin-bottom: 70px"
              :width="606"
              :height="542"
              type="Cyrusshare"
              name="SAVA DECK300 Mountain Bike 29"
              :minText="true"
              money="1,399.99"
            />
            <div class="min-product-wrapper" v-for="item in 2" :key="item">
              <productWrapperVue
                :width="269"
                :height="294"
                type="Cyrusshare"
                name="SAVA DECK300 Mountain Bike 29"
                :minText="true"
                money="1,399.99"
              />
            </div>
          </section>
        </article>
      </section>
      <!-- 内容区域 end -->
    </article>
    <footer class="home-footer">
      <section>
        <ul class="footer-items">
          <li>How We Help</li>
          <li>Retailers</li>
          <li>Interiors Designers</li>
          <li>Product Designers</li>
          <li>Wholesalers / Importers</li>
          <li>Artisans</li>
        </ul>
        <ul class="footer-items">
          <li>Get to Know Us</li>
          <li>About</li>
          <li>Policies</li>
          <li>Careers</li>
          <li>Press</li>
        </ul>
        <ul class="footer-items">
          <li>Join the Community</li>
          <li>Upcoming Events</li>
          <li>Become a Buyer</li>
          <li>Become a Seller</li>
        </ul>
        <ul class="footer-items">
          <li>Facebook</li>
          <li>Retailers</li>
          <li>Pinterest</li>
          <li>Twitter</li>
          <li>Instagram</li>
        </ul>
      </section>
      <div class="footer-sign">Author: Fenglekai</div>
    </footer>
  </div>
</template>

<script lang="ts">
import { reactive, toRefs, defineComponent } from "vue";
import productWrapperVue from "@/components/productWrapper.vue";
export default defineComponent({
  setup() {
    const state = reactive({
      message: "home",
    });
    return {
      ...toRefs(state),
    };
  },
  components: { productWrapperVue },
});
</script>

<style lang="scss" scoped>
@import "@/style/global.scss";
.home-header {
  width: 100vw;
  height: 100px;
  display: flex;
  justify-content: space-between;
  align-content: center;
  .home-logo {
    margin: 0 80px;
    line-height: 100px;
    font-size: 0;
    img {
      vertical-align: middle;
    }
  }
  .search-login {
    line-height: 100px;
  }
}
.home-nav {
  width: calc(100vw - 160px);
  height: 45px;
  background-color: rgba(244, 244, 244, 1);
  padding: 0 80px;
  ul {
    margin: 0;
    padding: 0;
    list-style: none;
    line-height: 45px;
    li {
      display: inline-block;
      margin-right: 25px;
      cursor: pointer;
    }
  }
}
.home-article {
  .default-image {
    position: relative;
    padding-bottom: 200px;
    .content-text {
      position: absolute;
      text-align: center;
      width: 800px;
      color: $white;
      font-size: 50px;
      top: 28%;
      left: 50%;
      transform: translate(-50%, -50%);
    }
    img {
      width: 100%;
      height: auto;
      max-height: 100%;
    }
    .carousel {
      width: calc(100% - 160px);
      height: 300px;
      background-color: #ffffff;
      position: absolute;
      bottom: -150px;
      left: 5%;
      transform: translateY(-50%);
      box-shadow: 0 0 68px rgb(9, 9, 9, 0.3);
    }
  }
  .content-wrapper {
    width: calc(100% - 160px);
    margin: 85px auto 0 auto;
    .top-seller {
      .seller-title {
        font-size: 30px;
        color: $primary-color;
        margin-bottom: 20px;
      }
      .product-items {
        display: flex;
        justify-content: space-between;
        .product-wrapper {
          width: 380px;
          height: 380px;
          border: 1px solid #e0e0e0;
          img {
            display: block;
            width: 100%;
            height: 280px;
          }
          .describe {
            height: 100px - 40px;
            padding: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            section {
              p:first-child {
                color: rgba(117, 117, 117, 1);
                font-size: 14px;
              }
              p:nth-child(2) {
                color: rgba(0, 0, 0, 1);
                font-size: 16px;
              }
              p:last-child {
                color: $primary-color;
                font-size: 19px;
              }
            }
            img {
              width: 15px;
              height: 23px;
              cursor: pointer;
            }
          }
        }
      }
      .more-wrapper {
        margin-top: 37px;
        text-align: center;
        .to-more {
          font-size: 16px;
          color: rgba(117, 117, 117, 1);
          text-decoration: none;
        }
      }
    }
    .problem {
      width: 100%;
      display: flex;
      align-items: center;
      margin-top: 130px;
      section {
        flex: 1;
        p:first-child {
          font-size: 30px;
          color: $primary-color;
          margin-bottom: 20px;
        }
        button:last-child {
          margin-top: 16px;
        }
      }
      aside {
        flex: 1;
        text-align: center;
        img {
          width: 379px;
          height: 241px;
        }
      }
    }
    .more-product-wrapper {
      display: flex;
      justify-content: space-between;
      margin-top: 156px;
      .list-wrapper {
        flex: 0.9;
        display: inherit;
        flex-wrap: wrap;
        .min-product-wrapper {
          margin-bottom: 70px;
          flex: 0.9;
          display: flex;
          justify-content: space-between;
        }
      }
    }
  }
}
.home-footer {
  width: calc(100% - 160px);
  margin: 30px auto 0 auto;
  section {
    display: flex;
    justify-content: space-evenly;
    .footer-items {
      list-style: none;
      li:first-child {
        font-size: 24px;
        color: rgba(28, 28, 27, 1);
      }
      li {
        font-size: 14px;
        color: rgba(28, 28, 27, 1);
        line-height: 30px;
      }
    }
  }
  .footer-sign {
    margin-top: 22px;
    padding: 19px 0 22px 0;
    text-align: center;
    border-top: 1px solid #c6c6c5;
  }
}
</style>