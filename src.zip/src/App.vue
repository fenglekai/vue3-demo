<script setup>
// This starter template is using Vue 3 <script setup> SFCs
// Check out https://v3.vuejs.org/api/sfc-script-setup.html#sfc-script-setup
// import HelloWorld from './components/HelloWorld.vue'
</script>

<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png" />
  <HelloWorld msg="Hello Vue 3 + Vite" /> -->
  <div style="min-width: 1440px">
    <router-view></router-view>
  </div>
</template>

<script>
let roll = 0; // 滚动的值
let stop = 0; // 对比时间的值
let timer = null;
document.getElementById("app").addEventListener("scroll", function () {
  var e = event || event.target;
  // console.log(e.srcElement.scrollTop)
  // 每次滑动前都清除一遍我们定义的定时器
  clearTimeout(timer);
  // 每次滚动的时候，都让app回到原来的宽度
  document.getElementById("app").style.width = "calc(100vw - 0px)";
  // 这里我设置的是300毫秒，您可以更改您想要的间隔秒数
  timer = setTimeout("JudgeScroll()", 300);
  roll = e.srcElement.scrollTop;
});
function JudgeScroll() {
  // console.log(roll,stop)
  stop = document.getElementById("app").scrollTop;
  if (stop == roll) {
    // console.log('滚动停止');
    // 判断如果相等，就把app宽度增加18px，达到隐藏滚动条的效果
    document.getElementById("app").style.width = "calc(100vw + 18px)";
  }
}
</script>

<style>
#app {
  font-family: SourceHanSansCN-Regular;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  color: rgba(117, 117, 117, 1);
}
body {
  margin: 0;
  padding: 0;
  /* 悬浮滚动条 */
  overflow: overlay;
}
p {
  margin: 0;
}
/*定义滚动条高宽及背景
 高宽分别对应横竖滚动条的尺寸*/
::-webkit-scrollbar {
  width: 6px;
  height: 6px;
  background-color: transparent;
  margin-right: 2px;
}
/*定义滚动条轨道
 内阴影+圆角*/
::-webkit-scrollbar-track {
  -webkit-box-shadow: inset 0 0 6px transparent;
  border-radius: 10px;
  background-color: transparent;
}
/*定义滑块
 内阴影+圆角*/
::-webkit-scrollbar-thumb {
  border-radius: 10px;
  -webkit-box-shadow: inset 0 0 6px rgba(0, 0, 0, 0.3);
  background-color: rgba(255, 255, 255, 0.5);
}
</style>
